""" presql """
__version__ = "1.0.0"
from .presql import PreSQL
__all__ = ["presql"]