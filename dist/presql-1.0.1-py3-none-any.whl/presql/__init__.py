""" presql """
__version__ = "1.0.1"
from .presql import PreSQL
__all__ = ["presql"]