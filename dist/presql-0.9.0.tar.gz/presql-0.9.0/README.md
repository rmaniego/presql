# presql
PostgreSQL and Psycopg2 wrapper.
